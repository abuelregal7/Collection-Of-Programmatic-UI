//
//  Structures.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import Foundation

struct PostData {
    var postImage:String!
    var likeCount:String!
    var liked:Bool!
    var comments:String!
    var profileImage:String!
    var profileName:String!
    var isVerified:Bool!
}
