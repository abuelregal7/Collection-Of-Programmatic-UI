//
//  Custom.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColor {
    static let appRed:UIColor = UIColor(red: 251/255, green: 57/255, blue: 88/255, alpha: 1)
    static let appYellow:UIColor = UIColor(red: 255/255, green: 200/255, blue: 56/255, alpha: 1)
    static let backgroundColor:UIColor = UIColor(red: 242/255, green: 248/255, blue: 255/255, alpha: 1)
    static let appBlue:UIColor = UIColor(red: 38/255, green: 180/255, blue: 255/255, alpha: 1)
}
