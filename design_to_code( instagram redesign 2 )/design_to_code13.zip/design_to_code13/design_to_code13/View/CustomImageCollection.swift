//
//  CustomImageCollection.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 15/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomImageCollection: UIView {
    
    let image1:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 17.5
        img.layer.borderColor = UIColor.white.cgColor
        img.layer.borderWidth = 1
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "prof-img7")
        img.clipsToBounds = true
        return img
    }()
    
    let image2:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 17.5
        img.layer.borderColor = UIColor.white.cgColor
        img.layer.borderWidth = 1
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "prof-img6")
        img.clipsToBounds = true
        return img
    }()
    
    let image3:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 17.5
        img.layer.borderColor = UIColor.white.cgColor
        img.layer.borderWidth = 1
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "prof-img5")
        img.clipsToBounds = true
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(image3)
        addSubview(image2)
        addSubview(image1)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            image1.leadingAnchor.constraint(equalTo: leadingAnchor),
            image1.widthAnchor.constraint(equalToConstant: 35),
            image1.heightAnchor.constraint(equalToConstant: 35),
            image1.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            image2.leadingAnchor.constraint(equalTo: image1.trailingAnchor, constant: -17.5),
            image2.widthAnchor.constraint(equalToConstant: 35),
            image2.heightAnchor.constraint(equalToConstant: 35),
            image2.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            image3.leadingAnchor.constraint(equalTo: image2.trailingAnchor, constant: -17.5),
            image3.widthAnchor.constraint(equalToConstant: 35),
            image3.heightAnchor.constraint(equalToConstant: 35),
            image3.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
