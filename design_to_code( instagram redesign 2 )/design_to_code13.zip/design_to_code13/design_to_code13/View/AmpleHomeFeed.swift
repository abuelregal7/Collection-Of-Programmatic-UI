//
//  AmpleHomeFeed.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class AmpleHomeFeed: UIView {
    
    var data = [PostData]()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.register(StoryHeaderCollectionReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "StoryHeaderCollectionReusableView")
        cv.register(PostCollectionViewCell.self, forCellWithReuseIdentifier: "PostCollectionViewCell")
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        cv.delaysContentTouches = false
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        addSubview(collectionView)
        collectionView.pin(to: self)
        
        data = [
            PostData(postImage: "post-img5", likeCount: "224k", liked: true, comments: "23k", profileImage: "prof-img1", profileName: "Apple", isVerified:true),
            PostData(postImage: "post-img7", likeCount: "102k", liked: true, comments: "10k", profileImage: "prof-img2", profileName: "Nasa", isVerified:true),
            PostData(postImage: "post-img8", likeCount: "142k", liked: true, comments: "15k", profileImage: "prof-img3", profileName: "NatGeo", isVerified:true),
            PostData(postImage: "post-img1", likeCount: "4,2k", liked: false, comments: "1k", profileImage: "prof-img4", profileName: "Skye", isVerified:false),
            PostData(postImage: "post-img2", likeCount: "12k", liked: true, comments: "2k", profileImage: "prof-img5", profileName: "Coulson", isVerified:false),
            PostData(postImage: "post-img6", likeCount: "15k", liked: false, comments: "1,2k", profileImage: "prof-img6", profileName: "Brett", isVerified:false),
            PostData(postImage: "post-img4", likeCount: "9,2k", liked: false, comments: "2k", profileImage: "prof-img7", profileName: "Ward", isVerified:false),
            PostData(postImage: "post-img3", likeCount: "4,6k", liked: false, comments: "2,2k", profileImage: "prof-img8", profileName: "Jack", isVerified:false)
        ]
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension AmpleHomeFeed:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,PostActions {
    
    func didTapLike(for cell: PostCollectionViewCell) {
        guard let indexPath = collectionView.indexPath(for: cell) else { return }
        self.data[indexPath.row].liked = true
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
            case UICollectionView.elementKindSectionHeader:
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "StoryHeaderCollectionReusableView", for: indexPath) as! StoryHeaderCollectionReusableView
                return header
            default:
                return UICollectionReusableView()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostCollectionViewCell", for: indexPath) as! PostCollectionViewCell
        cell.layer.anchorPointZ = CGFloat(10 - indexPath.row)
        cell.backgroundColor = .clear
        cell.data = data[indexPath.row]
        cell.delegate = self
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 500)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 130)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return -60
    }
}

