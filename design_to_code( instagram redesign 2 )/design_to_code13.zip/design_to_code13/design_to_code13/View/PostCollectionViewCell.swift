//
//  PostCollectionViewCell.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

protocol PostActions {
    func didTapLike(for cell: PostCollectionViewCell)
}

class PostCollectionViewCell: UICollectionViewCell {
    
    var data:PostData?{
        didSet{
            manageData()
        }
    }
    var delegate:PostActions?
    
    let postCard:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 40
        return v
    }()
    
    lazy var postImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img1")
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 40
        img.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        img.clipsToBounds = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        tap.numberOfTapsRequired = 2
        img.addGestureRecognizer(tap)
        img.isUserInteractionEnabled = true
        return img
    }()
    
    let heartBackView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let heartImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tapLike")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let topOverlayView:OverlayGradientView = {
        let v = OverlayGradientView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 40
        v.gradientLayer.colors = [UIColor.clear.cgColor, UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor]
        v.gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        v.gradientLayer.endPoint = CGPoint(x: 0, y: 0)
        v.layer.maskedCorners = [.layerMinXMinYCorner , .layerMaxXMinYCorner]
        return v
    }()
    
    let bottomOverlayView:OverlayGradientView = {
        let v = OverlayGradientView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.gradientLayer.colors = [UIColor.clear.cgColor, UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor]
        v.gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        v.gradientLayer.endPoint = CGPoint(x: 0, y: 1)
        return v
    }()
    
    let profilePicture:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img2")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = 20
        return img
    }()
    
    let username:UILabel = {
        let l = UILabel()
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let stackView:UIStackView = {
        let v = UIStackView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.axis = .horizontal
        v.distribution = .fillEqually
        v.spacing = 0
        return v
    }()
    
    //MARK:- LIKE VIEW
    let likeView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        v.layer.masksToBounds = true
        return v
    }()
    
    let likeBlurrView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        v.layer.masksToBounds = true
        return v
    }()
    
    let likeButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "like"), for: .normal)
        return btn
    }()
    
    let likeLabel:UILabel = {
        let l = UILabel()
        l.text = "20k"
        l.font = UIFont(name: "Avenir-Heavy", size: 15)
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    //MARK:- COMMENT VIEW
    let commentView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        return v
    }()
    
    let commentButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "comment"), for: .normal)
        return btn
    }()
    
    let commentLabel:UILabel = {
        let l = UILabel()
        l.text = "968"
        l.font = UIFont(name: "Avenir-Heavy", size: 15)
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    //MARK:- SHARE BUTTON
    let shareButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "share"), for: .normal)
        return btn
    }()
    
    //MARK:- SAVE BUTTON
    let saveButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "save"), for: .normal)
        return btn
    }()
    
    let imageCollection:CustomImageCollection = {
        let v = CustomImageCollection()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.image1.layer.cornerRadius = 15
        v.image2.layer.cornerRadius = 15
        v.image3.layer.cornerRadius = 15
        return v
    }()
    
    let captionLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Lorem ipsum Lorem Ipsum Lorem ipsum Lorem Ipsum"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        l.textColor = .white
        return l
    }()
    
    let moreBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("More", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.titleLabel?.font = UIFont(name: "Avenir-Medium", size: 13)
        btn.backgroundColor = .white
        btn.layer.cornerRadius = 17.5
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(postCard)
        postCard.addSubview(postImage)
        postCard.addSubview(topOverlayView)
        postCard.addSubview(bottomOverlayView)
        postCard.addSubview(profilePicture)
        postCard.addSubview(username)
        postCard.addSubview(stackView)
        stackView.addArrangedSubview(likeView)
        likeView.addSubview(likeBlurrView)
        likeView.addSubview(likeButton)
        likeView.addSubview(likeLabel)
        stackView.addArrangedSubview(commentView)
        commentView.addSubview(commentLabel)
        commentView.addSubview(commentButton)
        postCard.addSubview(shareButton)
        postCard.addSubview(saveButton)
        postCard.addSubview(heartBackView)
        heartBackView.addSubview(heartImage)
        postCard.addSubview(imageCollection)
        postCard.addSubview(captionLabel)
        postCard.addSubview(moreBtn)
        likeBlurrView.pin(to: likeView)
        postCard.pin(to: self)
        postImage.pin(to: postCard)
        setUpConstraints()
        
        let blurEffect = UIBlurEffect(style:.light)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = likeBlurrView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        likeBlurrView.addSubview(blurEffectView)
        
        heartBackView.isHidden = true
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            topOverlayView.topAnchor.constraint(equalTo: topAnchor),
            topOverlayView.leadingAnchor.constraint(equalTo: leadingAnchor),
            topOverlayView.trailingAnchor.constraint(equalTo: trailingAnchor),
            topOverlayView.heightAnchor.constraint(equalToConstant: 130),
            
            profilePicture.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            profilePicture.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            profilePicture.widthAnchor.constraint(equalToConstant: 45),
            profilePicture.heightAnchor.constraint(equalToConstant: 45),
            
            bottomOverlayView.bottomAnchor.constraint(equalTo: bottomAnchor),
            bottomOverlayView.leadingAnchor.constraint(equalTo: leadingAnchor),
            bottomOverlayView.trailingAnchor.constraint(equalTo: trailingAnchor),
            bottomOverlayView.heightAnchor.constraint(equalToConstant: 200),
            
            username.leadingAnchor.constraint(equalTo: profilePicture.trailingAnchor, constant: 10),
            username.topAnchor.constraint(equalTo: topAnchor, constant: 29),
            
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            stackView.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -15),
            stackView.heightAnchor.constraint(equalToConstant: 50),
            stackView.widthAnchor.constraint(equalToConstant: 170),
            
            likeButton.leadingAnchor.constraint(equalTo: likeView.leadingAnchor, constant: 12),
            likeButton.widthAnchor.constraint(equalToConstant: 20),
            likeButton.heightAnchor.constraint(equalToConstant: 20),
            likeButton.centerYAnchor.constraint(equalTo: likeView.centerYAnchor),
            
            commentButton.leadingAnchor.constraint(equalTo: commentView.leadingAnchor, constant: 12),
            commentButton.widthAnchor.constraint(equalToConstant: 20),
            commentButton.heightAnchor.constraint(equalToConstant: 20),
            commentButton.centerYAnchor.constraint(equalTo: commentView.centerYAnchor),
            
            shareButton.leadingAnchor.constraint(equalTo: stackView.trailingAnchor, constant: 5),
            shareButton.widthAnchor.constraint(equalToConstant: 25),
            shareButton.heightAnchor.constraint(equalToConstant: 25),
            shareButton.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -25),
            
            saveButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            saveButton.widthAnchor.constraint(equalToConstant: 25),
            saveButton.heightAnchor.constraint(equalToConstant: 25),
            saveButton.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -25),
            
            likeLabel.leadingAnchor.constraint(equalTo: likeButton.trailingAnchor, constant: 5),
            likeLabel.trailingAnchor.constraint(equalTo: likeView.trailingAnchor , constant: -3),
            likeLabel.centerYAnchor.constraint(equalTo: likeView.centerYAnchor),
            
            commentLabel.leadingAnchor.constraint(equalTo: commentButton.trailingAnchor, constant: 5),
            commentLabel.trailingAnchor.constraint(equalTo: commentView.trailingAnchor , constant: -3),
            commentLabel.centerYAnchor.constraint(equalTo: commentView.centerYAnchor),
            
            heartBackView.leadingAnchor.constraint(equalTo: leadingAnchor),
            heartBackView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -50),
            heartBackView.trailingAnchor.constraint(equalTo: trailingAnchor),
            heartBackView.topAnchor.constraint(equalTo: topAnchor),
            
            heartImage.centerYAnchor.constraint(equalTo: heartBackView.centerYAnchor),
            heartImage.centerXAnchor.constraint(equalTo: heartBackView.centerXAnchor),
            heartImage.widthAnchor.constraint(equalToConstant: 90),
            heartImage.heightAnchor.constraint(equalToConstant: 90),
            
            imageCollection.leadingAnchor.constraint(equalTo: postCard.leadingAnchor, constant: 20),
            imageCollection.bottomAnchor.constraint(equalTo: postCard.bottomAnchor, constant: -20),
            imageCollection.heightAnchor.constraint(equalToConstant: 35),
            imageCollection.widthAnchor.constraint(equalToConstant: 70),
            
            captionLabel.leadingAnchor.constraint(equalTo: imageCollection.trailingAnchor, constant: 15),
            captionLabel.trailingAnchor.constraint(equalTo: moreBtn.leadingAnchor, constant: -15),
            captionLabel.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20),
            
            moreBtn.trailingAnchor.constraint(equalTo: postCard.trailingAnchor, constant: -15),
            moreBtn.bottomAnchor.constraint(equalTo: postCard.bottomAnchor, constant: -20),
            moreBtn.heightAnchor.constraint(equalToConstant: 35),
            moreBtn.widthAnchor.constraint(equalToConstant: 70),
        ])
    }
    
    @objc func doubleTapped(){
        delegate?.didTapLike(for: self)
        self.likeView.backgroundColor = CustomColor.appRed
        self.likeBlurrView.isHidden = true
        self.heartBackView.isHidden = false
        UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.heartImage.transform = .init(scaleX: 1.8, y: 1.8)
        } ,completion:{ finished in
            self.heartImage.transform = .identity
            self.heartBackView.isHidden = true
        })
    }
    
    func manageData(){
        guard let data = data else {return}
        commentLabel.text = data.comments
        likeLabel.text = data.likeCount
        profilePicture.image = UIImage(named: data.profileImage)
        postImage.image = UIImage(named: data.postImage)
        setUserNameAttributedText()
        
        if data.liked {
            likeBlurrView.isHidden = true
            likeView.backgroundColor = CustomColor.appRed
        } else {
            likeBlurrView.isHidden = false
            likeView.backgroundColor = .clear
        }
    }
    
    private func setUserNameAttributedText(){
        guard let data = data else { return }
        let attributedText = NSMutableAttributedString(string:"\(data.profileName ?? "") " , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 17)!])
        
        if data.isVerified {
            let font = UIFont.systemFont(ofSize: 15)
            let verifiyImg = UIImage(named:"verify")
            let verifiedImage = NSTextAttachment()
            verifiedImage.image = verifiyImg
            verifiedImage.bounds = CGRect(x: 0, y: (font.capHeight - 15).rounded() / 2, width: 15, height: 15)
            verifiedImage.setImageHeight(height: 15)
            let imgString = NSAttributedString(attachment: verifiedImage)
            attributedText.append(imgString)
        }
        
        username.attributedText = attributedText
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
