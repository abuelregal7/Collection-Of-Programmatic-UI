//
//  StoryCollectionViewCell.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class StoryCollectionViewCell: UICollectionViewCell {
    
    let addStoryBackView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 30
        v.backgroundColor = .white
        v.layer.borderColor = UIColor(white: 0, alpha: 0.1).cgColor
        v.layer.borderWidth = 2
        return v
    }()
    
    let addStoryImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "addStory")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let backView:OverlayGradientView = {
        let v = OverlayGradientView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .orange
        v.layer.cornerRadius = 30
        v.gradientLayer.colors = [CustomColor.appRed.cgColor , CustomColor.appYellow.cgColor]
        v.gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        v.gradientLayer.endPoint = CGPoint(x:0, y: 1)
        return v
    }()
    
    let backTopView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 28
        return v
    }()
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.image = UIImage(named: "img1")
        img.layer.cornerRadius = 25
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let username:UILabel = {
        let l = UILabel()
        l.text = "Laura"
        l.textAlignment = .center
        l.textColor = .black
        l.font = UIFont(name: "Avenir-Medium", size: 15)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(backView)
        addSubview(username)
        backView.addSubview(backTopView)
        backTopView.addSubview(imageView)
        addSubview(addStoryBackView)
        addStoryBackView.addSubview(addStoryImage)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            backView.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            backView.centerXAnchor.constraint(equalTo: centerXAnchor),
            backView.widthAnchor.constraint(equalToConstant: 70),
            backView.heightAnchor.constraint(equalToConstant: 70),
            
            backTopView.centerXAnchor.constraint(equalTo: backView.centerXAnchor),
            backTopView.centerYAnchor.constraint(equalTo: backView.centerYAnchor),
            backTopView.heightAnchor.constraint(equalToConstant: 65),
            backTopView.widthAnchor.constraint(equalToConstant: 65),
            
            imageView.centerXAnchor.constraint(equalTo: backTopView.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: backTopView.centerYAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 60),
            imageView.widthAnchor.constraint(equalToConstant: 60),
            
            username.topAnchor.constraint(equalTo: backView.bottomAnchor, constant: 5),
            username.leadingAnchor.constraint(equalTo: leadingAnchor),
            username.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            addStoryBackView.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            addStoryBackView.centerXAnchor.constraint(equalTo: centerXAnchor),
            addStoryBackView.widthAnchor.constraint(equalToConstant: 70),
            addStoryBackView.heightAnchor.constraint(equalToConstant: 70),
            
            addStoryImage.centerXAnchor.constraint(equalTo: addStoryBackView.centerXAnchor),
            addStoryImage.centerYAnchor.constraint(equalTo: addStoryBackView.centerYAnchor),
            addStoryImage.widthAnchor.constraint(equalToConstant: 20),
            addStoryImage.heightAnchor.constraint(equalToConstant: 20)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
