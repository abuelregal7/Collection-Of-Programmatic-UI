//
//  StoryHeaderCollectionReusableView.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct StoryHeader {
    let image:String!
    let name:String!
}

class StoryHeaderCollectionReusableView: UICollectionReusableView {
    
    let data:[StoryHeader] = [
        StoryHeader(image: "prof-img3", name: "NatGeo"),
        StoryHeader(image: "prof-img6", name: "Brett"),
        StoryHeader(image: "prof-img2", name: "Nasa"),
        StoryHeader(image: "prof-img1", name: "Apple"),
        StoryHeader(image: "prof-img4", name: "Skye"),
        StoryHeader(image: "prof-img5", name: "Coulson"),
        StoryHeader(image: "prof-img8", name: "Jack"),
        StoryHeader(image: "prof-img7", name: "Ward")
    ]
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.register(StoryCollectionViewCell.self, forCellWithReuseIdentifier: "StoryCollectionViewCell")
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        cv.delegate = self
        cv.dataSource = self
        cv.delaysContentTouches = false
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension StoryHeaderCollectionReusableView:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StoryCollectionViewCell", for: indexPath) as! StoryCollectionViewCell
        if indexPath.row == 0 {
            cell.backView.isHidden = true
            cell.addStoryBackView.isHidden = false
            cell.username.text = "Add Story"
        } else {
            cell.backView.isHidden = false
            cell.addStoryBackView.isHidden = true
            cell.imageView.image = UIImage(named: data[indexPath.row - 1].image)
            cell.username.text = data[indexPath.row - 1].name
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 80, height: 110)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }
}
