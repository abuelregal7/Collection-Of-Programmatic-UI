//
//  CleanPostCollectionViewCell.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 15/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

protocol PostActions2 {
    func didTapLike(for cell: CleanPostCollectionViewCell)
}

class CleanPostCollectionViewCell: UICollectionViewCell {
    
    var delegate:PostActions2?
    var data:PostData?{
        didSet{
            manageData()
        }
    }
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.05).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 0)
        v.layer.shadowRadius = 10
        v.layer.shadowOpacity = 1
        v.layer.cornerRadius = 30
        return v
    }()
    
    let profilePicture:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img2")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = 22.5
        img.layer.borderColor = UIColor(white: 0, alpha: 0.1).cgColor
        img.layer.borderWidth = 1.5
        return img
    }()
    
    let username:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        return l
    }()
    
    let moreOptionBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setImage(UIImage(named: "moreBtn"), for: .normal)
        return btn
    }()
    
    let stackView:UIStackView = {
        let v = UIStackView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.axis = .horizontal
        v.distribution = .fillEqually
        v.spacing = 0
        return v
    }()
    
    //MARK:- LIKE VIEW
    let likeView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        v.layer.masksToBounds = true
        return v
    }()
    
    let likeBlurrView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        v.layer.masksToBounds = true
        return v
    }()
    
    let likeButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "like")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .black
        return btn
    }()
    
    let likeLabel:UILabel = {
        let l = UILabel()
        l.text = "20k"
        l.font = UIFont(name: "Avenir-Heavy", size: 15)
        l.textColor = .black
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    //MARK:- COMMENT VIEW
    let commentView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 25
        return v
    }()
    
    let commentButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "comment")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .black
        return btn
    }()
    
    let commentLabel:UILabel = {
        let l = UILabel()
        l.text = "968"
        l.font = UIFont(name: "Avenir-Heavy", size: 15)
        l.textColor = .black
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    //MARK:- SHARE BUTTON
    let shareButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "share")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .black
        return btn
    }()
    
    //MARK:- SAVE BUTTON
    let saveButton:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "save")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = UIColor.black
        return btn
    }()
    
    let imageCollection:CustomImageCollection = {
        let v = CustomImageCollection()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.3).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 0)
        v.layer.shadowRadius = 10
        v.layer.shadowOpacity = 1
        return v
    }()
    
    let captionLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Lorem ipsum Lorem Ipsum Lorem ipsum Lorem Ipsum"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let moreBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("More", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.titleLabel?.font = UIFont(name: "Avenir-Medium", size: 13)
        btn.backgroundColor = UIColor(white: 0, alpha: 0.1)
        btn.layer.cornerRadius = 17.5
        return btn
    }()
    
    lazy var postImage:UIImageView = {
        let img = UIImageView()
        img.layer.cornerRadius = 20
        img.image = UIImage(named: "post-img3")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.translatesAutoresizingMaskIntoConstraints = false
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        tap.numberOfTapsRequired = 2
        img.addGestureRecognizer(tap)
        img.isUserInteractionEnabled = true
        return img
    }()
    
    let postImageShadow:UIView = {
        let v = UIView()
        v.layer.cornerRadius = 30
        v.backgroundColor = .white
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.2).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 15)
        v.layer.shadowRadius = 12
        v.layer.shadowOpacity = 1
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let heartBackView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let heartImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tapLike")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(cardView)
        cardView.addSubview(profilePicture)
        cardView.addSubview(username)
        cardView.addSubview(moreOptionBtn)
        stackView.addArrangedSubview(likeView)
        likeView.addSubview(likeBlurrView)
        likeView.addSubview(likeButton)
        likeView.addSubview(likeLabel)
        cardView.addSubview(stackView)
        stackView.addArrangedSubview(commentView)
        commentView.addSubview(commentLabel)
        commentView.addSubview(commentButton)
        cardView.addSubview(shareButton)
        cardView.addSubview(saveButton)
        cardView.addSubview(imageCollection)
        cardView.addSubview(captionLabel)
        cardView.addSubview(moreBtn)
        cardView.addSubview(postImageShadow)
        cardView.addSubview(postImage)
        cardView.addSubview(heartBackView)
        heartBackView.addSubview(heartImage)
        setUpConstraints()
        setUserNameAttributedText()
        
        let blurEffect = UIBlurEffect(style:.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = likeBlurrView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        likeBlurrView.addSubview(blurEffectView)
        
        heartBackView.isHidden = true
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 25),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -25),
            cardView.bottomAnchor.constraint(equalTo: bottomAnchor, constant:  -20),
            
            profilePicture.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            profilePicture.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 15),
            profilePicture.heightAnchor.constraint(equalToConstant: 45),
            profilePicture.widthAnchor.constraint(equalToConstant: 45),
            
            username.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            username.leadingAnchor.constraint(equalTo: profilePicture.trailingAnchor, constant: 15),
            
            moreOptionBtn.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -25),
            moreOptionBtn.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 20),
            moreOptionBtn.widthAnchor.constraint(equalToConstant: 30),
            moreOptionBtn.heightAnchor.constraint(equalToConstant: 30),
            
            stackView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            stackView.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -10),
            stackView.heightAnchor.constraint(equalToConstant: 50),
            stackView.widthAnchor.constraint(equalToConstant: 170),
            
            likeButton.leadingAnchor.constraint(equalTo: likeView.leadingAnchor, constant: 12),
            likeButton.widthAnchor.constraint(equalToConstant: 20),
            likeButton.heightAnchor.constraint(equalToConstant: 20),
            likeButton.centerYAnchor.constraint(equalTo: likeView.centerYAnchor),
            
            commentButton.leadingAnchor.constraint(equalTo: commentView.leadingAnchor, constant: 12),
            commentButton.widthAnchor.constraint(equalToConstant: 20),
            commentButton.heightAnchor.constraint(equalToConstant: 20),
            commentButton.centerYAnchor.constraint(equalTo: commentView.centerYAnchor),
            
            shareButton.leadingAnchor.constraint(equalTo: stackView.trailingAnchor, constant: 5),
            shareButton.widthAnchor.constraint(equalToConstant: 25),
            shareButton.heightAnchor.constraint(equalToConstant: 25),
            shareButton.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -25),
            
            saveButton.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            saveButton.widthAnchor.constraint(equalToConstant: 25),
            saveButton.heightAnchor.constraint(equalToConstant: 25),
            saveButton.bottomAnchor.constraint(equalTo: imageCollection.topAnchor, constant: -25),
            
            likeLabel.leadingAnchor.constraint(equalTo: likeButton.trailingAnchor, constant: 5),
            likeLabel.trailingAnchor.constraint(equalTo: likeView.trailingAnchor , constant: -3),
            likeLabel.centerYAnchor.constraint(equalTo: likeView.centerYAnchor),
            
            commentLabel.leadingAnchor.constraint(equalTo: commentButton.trailingAnchor, constant: 5),
            commentLabel.trailingAnchor.constraint(equalTo: commentView.trailingAnchor , constant: -3),
            commentLabel.centerYAnchor.constraint(equalTo: commentView.centerYAnchor),
            
            imageCollection.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            imageCollection.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -20),
            imageCollection.heightAnchor.constraint(equalToConstant: 35),
            imageCollection.widthAnchor.constraint(equalToConstant: 70),
            
            captionLabel.leadingAnchor.constraint(equalTo: imageCollection.trailingAnchor, constant: 15),
            captionLabel.trailingAnchor.constraint(equalTo: moreBtn.leadingAnchor, constant: -15),
            captionLabel.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 17),
            
            moreBtn.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            moreBtn.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -20),
            moreBtn.heightAnchor.constraint(equalToConstant: 35),
            moreBtn.widthAnchor.constraint(equalToConstant: 70),
            
            postImageShadow.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 25),
            postImageShadow.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -25),
            postImageShadow.topAnchor.constraint(equalTo: profilePicture.bottomAnchor, constant: 15),
            postImageShadow.bottomAnchor.constraint(equalTo: stackView.topAnchor, constant: -15),
            
            postImage.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            postImage.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            postImage.topAnchor.constraint(equalTo: profilePicture.bottomAnchor, constant: 15),
            postImage.bottomAnchor.constraint(equalTo: stackView.topAnchor, constant: -15),
            
            heartBackView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            heartBackView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            heartBackView.topAnchor.constraint(equalTo: profilePicture.bottomAnchor, constant: 15),
            heartBackView.bottomAnchor.constraint(equalTo: stackView.topAnchor, constant: -15),
            
            heartImage.centerYAnchor.constraint(equalTo: heartBackView.centerYAnchor),
            heartImage.centerXAnchor.constraint(equalTo: heartBackView.centerXAnchor),
            heartImage.widthAnchor.constraint(equalToConstant: 90),
            heartImage.heightAnchor.constraint(equalToConstant: 90)
        ])
    }
    
    private func setUserNameAttributedText(){
        guard let data = data else { return }
        let attributedText = NSMutableAttributedString(string:"\(data.profileName ?? "") " , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 17)!])
        
        if data.isVerified {
            let font = UIFont.systemFont(ofSize: 17)
            let verifyImg = UIImage(named:"verifyB")
            let verifiedImage = NSTextAttachment()
            verifiedImage.image = verifyImg
            verifiedImage.bounds = CGRect(x: 0, y: (font.capHeight - 17).rounded() / 2, width: 17, height: 17)
            verifiedImage.setImageHeight(height: 17)
            let imgString = NSAttributedString(attachment: verifiedImage)
            attributedText.append(imgString)
        }
        
        attributedText.append(NSAttributedString(string: "\nNew York" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 14)!, NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        
        username.attributedText = attributedText
    }
    
    @objc func doubleTapped(){
        delegate?.didTapLike(for: self)
        self.likeView.backgroundColor = CustomColor.appRed
        self.likeBlurrView.isHidden = true
        self.heartBackView.isHidden = false
        likeLabel.textColor = .white
        likeButton.tintColor = .white
        UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.heartImage.transform = .init(scaleX: 1.8, y: 1.8)
        } ,completion:{ finished in
            self.heartImage.transform = .identity
            self.heartBackView.isHidden = true
        })
    }
    
    func manageData(){
        guard let data = data else {return}
        commentLabel.text = data.comments
        likeLabel.text = data.likeCount
        profilePicture.image = UIImage(named: data.profileImage)
        postImage.image = UIImage(named: data.postImage)
        setUserNameAttributedText()
        
        if data.liked {
            likeBlurrView.isHidden = true
            likeView.backgroundColor = CustomColor.appRed
            likeLabel.textColor = .white
            likeButton.tintColor = .white
        } else {
            likeBlurrView.isHidden = false
            likeView.backgroundColor = .clear
            likeLabel.textColor = .black
            likeButton.tintColor = .black
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
