//
//  HomeViewController.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

enum PopupState{
    case open
    case close
}

class HomeViewController: UIViewController {
    
    var state:PopupState?
    var settingButton = UIButton(type: .system)
    
    let ampleView:AmpleHomeFeed = {
        let v = AmpleHomeFeed()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let cleanView:CleanHomeFeed = {
        let v = CleanHomeFeed()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    //MARK:- OptionView
    
    let optionView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 40
        v.layer.masksToBounds = true
        v.layer.maskedCorners = [.layerMaxXMaxYCorner , .layerMinXMaxYCorner]
        return v
    }()
    
    let optionBlurrView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.textColor = .white
        l.text = "Visualization"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let stackView:UIStackView = {
        let sv = UIStackView()
        sv.axis = .horizontal
        sv.distribution = .fillEqually
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.spacing = 20
        return sv
    }()
    
    //MARK:- Ample Btn View
    
    let ampleBtnView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let ampleBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("1", for: .normal)
        btn.titleLabel?.font = UIFont(name: "Avenir-Medium", size: 19)
        btn.backgroundColor = UIColor(white: 1, alpha: 0.3)
        btn.setTitleColor(.white, for: .normal)
        btn.layer.cornerRadius = 20
        btn.addTarget(self, action: #selector(ampleBtnPressed), for: .touchUpInside)
        btn.layer.borderColor = UIColor.white.cgColor
        btn.layer.borderWidth = 1.5
        return btn
    }()
    
    let ampleBtnLabel:UILabel = {
        let l = UILabel()
        l.text = "Ample"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Medium", size: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    //MARK:- Clean Btn View
    
    let cleanBtnView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let cleanBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("2", for: .normal)
        btn.titleLabel?.font = UIFont(name: "Avenir-Medium", size: 19)
        btn.backgroundColor = UIColor(white: 1, alpha: 0.3)
        btn.setTitleColor(.white, for: .normal)
        btn.layer.cornerRadius = 20
        btn.addTarget(self, action: #selector(cleanBtnPressed), for: .touchUpInside)
        btn.layer.borderColor = UIColor.white.cgColor
        return btn
    }()
    
    let cleanBtnLabel:UILabel = {
        let l = UILabel()
        l.text = "Clean"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Medium", size: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = CustomColor.backgroundColor
        view.addSubview(cleanView)
        view.addSubview(ampleView)
        view.addSubview(optionView)
        optionView.addSubview(optionBlurrView)
        optionView.addSubview(titleLabel)
        optionView.addSubview(stackView)
        stackView.addArrangedSubview(ampleBtnView)
        stackView.addArrangedSubview(cleanBtnView)
        ampleBtnView.addSubview(ampleBtn)
        ampleBtnView.addSubview(ampleBtnLabel)
        cleanBtnView.addSubview(cleanBtn)
        cleanBtnView.addSubview(cleanBtnLabel)
        
        optionBlurrView.pin(to: optionView)
        ampleView.pin(to: view)
        cleanView.pin(to: view)
        setUpCustomNavBar()
        
        let blurEffect = UIBlurEffect(style:.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = optionBlurrView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        optionBlurrView.addSubview(blurEffectView)
        setUpConstraints()
        
        state = .close
        optionView.isHidden = true
        optionView.alpha = 0
        optionView.transform = .init(scaleX: 0.80, y: 0.80)
        
        cleanView.isHidden = true
        cleanView.alpha = 0
    }
    
    func setUpCustomNavBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.layer.zPosition = -1
        
        navigationController?.navigationBar.barTintColor = CustomColor.backgroundColor
        navigationController?.navigationBar.isTranslucent = false
        
        let logo = UIImage(named: "logo")
        let imageView = UIImageView(image:logo)
        imageView.contentMode = .scaleAspectFit
        self.navigationItem.titleView = imageView
        
        let messageButton = UIButton(type: .system)
        messageButton.setImage(UIImage(named: "message")?.withRenderingMode(.alwaysOriginal), for: .normal)
        messageButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: messageButton)
        
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = messageButton
        navigationItem.setRightBarButton(rightBarButtonItem, animated: false)

        settingButton.setImage(UIImage(named: "setting")?.withRenderingMode(.alwaysOriginal), for: .normal)
        settingButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: settingButton)
        settingButton.addTarget(self, action: #selector(settingBtnPressed), for: .touchUpInside)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = settingButton
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            optionView.topAnchor.constraint(equalTo: view.topAnchor),
            optionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            optionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            optionView.heightAnchor.constraint(equalToConstant: 190),
            
            titleLabel.topAnchor.constraint(equalTo: optionView.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: optionView.centerXAnchor),
            
            stackView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 5),
            stackView.heightAnchor.constraint(equalToConstant: 100),
            stackView.widthAnchor.constraint(equalToConstant: 250),
            stackView.centerXAnchor.constraint(equalTo: optionView.centerXAnchor),
            
            ampleBtn.topAnchor.constraint(equalTo: ampleBtnView.topAnchor, constant: 10),
            ampleBtn.widthAnchor.constraint(equalToConstant: 70),
            ampleBtn.heightAnchor.constraint(equalToConstant: 80),
            ampleBtn.centerXAnchor.constraint(equalTo: ampleBtnView.centerXAnchor),
            ampleBtnLabel.topAnchor.constraint(equalTo: ampleBtn.bottomAnchor, constant: 12),
            ampleBtnLabel.centerXAnchor.constraint(equalTo: ampleBtnView.centerXAnchor),
            
            cleanBtn.topAnchor.constraint(equalTo: cleanBtnView.topAnchor, constant: 10),
            cleanBtn.widthAnchor.constraint(equalToConstant: 70),
            cleanBtn.heightAnchor.constraint(equalToConstant: 80),
            cleanBtn.centerXAnchor.constraint(equalTo: cleanBtnView.centerXAnchor),
            cleanBtnLabel.topAnchor.constraint(equalTo: cleanBtn.bottomAnchor, constant: 12),
            cleanBtnLabel.centerXAnchor.constraint(equalTo: cleanBtnView.centerXAnchor),
            
        ])
    }
    
    @objc func settingBtnPressed(){
        if state == .open {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                self.optionView.transform = .init(scaleX: 0.80, y: 0.80)
                self.optionView.alpha = 0
                self.optionView.isHidden = true
                self.settingButton.setImage(UIImage(named: "setting")?.withRenderingMode(.alwaysOriginal), for: .normal)
            }, completion: nil)
            state = .close
        } else {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                self.optionView.isHidden = false
                self.optionView.alpha = 1
                self.optionView.transform = .identity
                self.settingButton.setImage(UIImage(named: "close")?.withRenderingMode(.alwaysOriginal), for: .normal)
            }, completion: nil)
            state = .open
        }
    }
    
    @objc func cleanBtnPressed(){
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.cleanView.isHidden = false
            self.cleanView.alpha = 1
            self.ampleView.alpha = 0
            self.ampleBtn.layer.borderWidth = 0
            self.cleanBtn.layer.borderWidth = 1.5
        }, completion: { finish in
            self.ampleView.isHidden = true
        })
    }

    @objc func ampleBtnPressed(){
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.ampleView.isHidden = false
            self.ampleView.alpha = 1
            self.cleanView.alpha = 0
            self.ampleBtn.layer.borderWidth = 1.5
            self.cleanBtn.layer.borderWidth = 0
        }, completion: { finish in
            self.cleanView.isHidden = true
        })
    }
}
