//
//  CustomTabBarViewController.swift
//  design_to_code13
//
//  Created by Dheeraj Kumar Sharma on 14/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomTabBarViewController: UITabBarController {

    var homeViewController:UIViewController!
    var exploreViewController:UIViewController!
    var addViewController:UIViewController!
    var activityViewController:UIViewController!
    var profileViewController:UIViewController!
    
    var tabItem = UITabBarItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let vc1 = HomeViewController()
        homeViewController = UINavigationController(rootViewController: vc1)
        
        let vc2 = HomeViewController()
        exploreViewController = UINavigationController(rootViewController: vc2)
        
        let vc3 = HomeViewController()
        addViewController = UINavigationController(rootViewController: vc3)
        
        let vc4 = HomeViewController()
        activityViewController = UINavigationController(rootViewController: vc4)
        
        let vc5 = HomeViewController()
        profileViewController = UINavigationController(rootViewController: vc5)
        
        viewControllers = [homeViewController , exploreViewController , addViewController , activityViewController, profileViewController]
        
        setUpViews()
        
        customTab(selectedImage: "home-selected", deselectedImage: "home", indexOfTab: 0 , tabTitle: "")
        customTab(selectedImage: "search-selected", deselectedImage: "search", indexOfTab: 1 , tabTitle: "")
        customTab(selectedImage: "add-selected", deselectedImage: "add", indexOfTab: 2 , tabTitle: "")
        customTab(selectedImage: "activity-selected", deselectedImage: "activity", indexOfTab: 3 , tabTitle: "")
        customTab(selectedImage: "user-selected", deselectedImage: "user", indexOfTab: 4 , tabTitle: "")
    }
    
    func setUpViews(){
        self.tabBar.layer.masksToBounds = true
        self.tabBar.isTranslucent = true
        self.tabBar.barTintColor = .white
        self.tabBar.layer.cornerRadius = 40
        self.tabBar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    func customTab(selectedImage image1 : String , deselectedImage image2: String , indexOfTab index: Int , tabTitle title: String ){

        let selectedImage = UIImage(named: image1)!.withRenderingMode(.alwaysOriginal)
        let deselectedImage = UIImage(named: image2)!.withRenderingMode(.alwaysOriginal)
        
        tabItem = self.tabBar.items![index]
        tabItem.image = deselectedImage
        tabItem.selectedImage = selectedImage
        tabItem.title = .none
        tabItem.imageInsets.bottom = -20
    }

}
