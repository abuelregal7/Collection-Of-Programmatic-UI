//
//  Constants.swift
//  justDesign4
//
//  Created by Dheeraj Kumar Sharma on 14/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColors {
    static let appBackground:UIColor = UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
}
