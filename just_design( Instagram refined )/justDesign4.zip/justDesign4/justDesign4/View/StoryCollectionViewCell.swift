//
//  StoryCollectionViewCell.swift
//  justDesign4
//
//  Created by Dheeraj Kumar Sharma on 14/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class StoryCollectionViewCell: UICollectionViewCell {
    
    let profileImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = 35
        return img
    }()

    let loaderView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 35
        return v
    }()
    
    let addBtn:UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(systemName: "plus.circle.fill")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.imageView?.tintColor = .blue
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = .white
        btn.layer.cornerRadius = 12.5
        return btn
    }()
    
    let username:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textAlignment = .center
        l.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(profileImage)
        addSubview(username)
        addSubview(loaderView)
        loaderView.addSubview(addBtn)
        setUpContraints()
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            profileImage.widthAnchor.constraint(equalToConstant: 70),
            profileImage.heightAnchor.constraint(equalToConstant: 70),
            profileImage.centerXAnchor.constraint(equalTo: centerXAnchor),
            profileImage.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            
            loaderView.widthAnchor.constraint(equalToConstant: 70),
            loaderView.heightAnchor.constraint(equalToConstant: 70),
            loaderView.centerXAnchor.constraint(equalTo: centerXAnchor),
            loaderView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            
            addBtn.trailingAnchor.constraint(equalTo: loaderView.trailingAnchor),
            addBtn.bottomAnchor.constraint(equalTo: loaderView.bottomAnchor),
            addBtn.widthAnchor.constraint(equalToConstant: 25),
            addBtn.heightAnchor.constraint(equalToConstant: 25),
            
            username.topAnchor.constraint(equalTo: profileImage.bottomAnchor, constant: 10),
            username.leadingAnchor.constraint(equalTo: leadingAnchor,constant: 10),
            username.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            username.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
